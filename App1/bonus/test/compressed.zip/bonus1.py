text = input("Enter a title: ")

print("the length of title: ", len(text))
