meals = ['pizza', 'pasta', 'salad']

for meal in meals:
    print(meal.capitalize())